<?php

/**
 * @file
 * Template file for the FAQ page if set to show the answer in a new page.
 */

/**
 * Available variables:
 *
 * $list_style
 *   The style of the list, either ol or ul (ordered list or unordered list).
 * $list_items
 *   An array of nodes to be displayed in the list.
 * $list
 *   Pre-formatted list.
 */
?>
<?php
print $list;
